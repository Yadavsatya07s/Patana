"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import ProductCard from "./product-card"
import { API_BASE_URL } from "@/lib/constants"

interface FeaturedProductsProps {
  setToast: (toast: { message: string; type: "success" | "error" | "info" }) => void
}

export default function FeaturedProducts({ setToast }: FeaturedProductsProps) {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchFeaturedProducts()
  }, [])

  const fetchFeaturedProducts = async () => {
    try {
      setLoading(true)
      const response = await fetch(`${API_BASE_URL}products.php?featured=1&limit=8`)
      const data = await response.json()
      if (data.success) {
        setProducts(data.products || [])
      }
    } catch (error) {
      console.error("Error fetching products:", error)
      setToast({ message: "Failed to load products", type: "error" })
    } finally {
      setLoading(false)
    }
  }

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-12">
        <div>
          <h2 className="text-3xl md:text-4xl font-bold mb-2">Featured Products</h2>
          <p className="text-muted-foreground">Curated selections from top sellers</p>
        </div>
        <Link
          href="/browse"
          className="px-6 py-2 rounded-lg border border-primary text-primary hover:bg-primary/10 transition-colors"
        >
          View All
        </Link>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="bg-muted h-48 rounded-lg mb-4"></div>
              <div className="bg-muted h-4 rounded mb-2"></div>
              <div className="bg-muted h-4 rounded w-3/4"></div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 animate-slide-up">
          {products.map((product: any) => (
            <ProductCard key={product.id} product={product} setToast={setToast} />
          ))}
        </div>
      )}
    </section>
  )
}

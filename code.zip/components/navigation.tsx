"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Menu, X, Sun, Moon, LogOut, Wallet } from "lucide-react"

interface NavigationProps {
  theme: "light" | "dark"
  toggleTheme: () => void
  isLoggedIn: boolean
}

export default function Navigation({ theme, toggleTheme, isLoggedIn }: NavigationProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [walletBalance, setWalletBalance] = useState(0)
  const router = useRouter()

  useEffect(() => {
    if (isLoggedIn) {
      const balance = localStorage.getItem("wallet_balance")
      setWalletBalance(balance ? Number.parseFloat(balance) : 0)
    }
  }, [isLoggedIn])

  const handleLogout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("user_id")
    localStorage.removeItem("user_type")
    router.push("/")
    setIsOpen(false)
  }

  return (
    <nav className="sticky top-0 z-50 border-b border-border bg-card/95 backdrop-blur-sm animate-slide-down">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center font-bold text-primary-foreground text-sm group-hover:shadow-lg group-hover:shadow-primary/50 transition-all">
              BW
            </div>
            <span className="hidden sm:block font-bold text-lg bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              BWM Store
            </span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-6">
            <Link href="/browse" className="text-sm hover:text-primary transition-colors">
              Browse
            </Link>
            <Link href="/categories" className="text-sm hover:text-primary transition-colors">
              Categories
            </Link>
            <Link href="/sell" className="text-sm hover:text-primary transition-colors">
              Sell
            </Link>
          </div>

          {/* Right side actions */}
          <div className="flex items-center gap-3">
            {/* Wallet Balance */}
            {isLoggedIn && (
              <Link
                href="/wallet"
                className="hidden sm:flex items-center gap-1 px-3 py-2 rounded-lg border border-border hover:border-primary hover:bg-card text-xs font-medium transition-colors group"
              >
                <Wallet className="w-4 h-4 text-primary group-hover:scale-110 transition-transform" />
                <span>₹{walletBalance.toFixed(2)}</span>
              </Link>
            )}

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg border border-border hover:border-primary hover:bg-card transition-colors"
              aria-label="Toggle theme"
            >
              {theme === "dark" ? (
                <Sun className="w-5 h-5 text-yellow-500" />
              ) : (
                <Moon className="w-5 h-5 text-slate-400" />
              )}
            </button>

            {/* Auth Links */}
            {!isLoggedIn ? (
              <div className="hidden sm:flex gap-2">
                <Link
                  href="/login"
                  className="px-4 py-2 rounded-lg border border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-200"
                >
                  Login
                </Link>
                <Link
                  href="/register"
                  className="px-4 py-2 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground hover:shadow-lg hover:shadow-primary/50 transition-all duration-200"
                >
                  Sign Up
                </Link>
              </div>
            ) : (
              <button
                onClick={handleLogout}
                className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-lg border border-border text-destructive hover:bg-destructive/10 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm">Logout</span>
              </button>
            )}

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden p-2 rounded-lg border border-border hover:bg-card"
            >
              {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden pb-4 border-t border-border animate-slide-down">
            <div className="flex flex-col gap-2 pt-4">
              <Link
                href="/browse"
                className="px-4 py-2 rounded-lg hover:bg-card transition-colors"
                onClick={() => setIsOpen(false)}
              >
                Browse Products
              </Link>
              <Link
                href="/categories"
                className="px-4 py-2 rounded-lg hover:bg-card transition-colors"
                onClick={() => setIsOpen(false)}
              >
                Categories
              </Link>
              <Link
                href="/sell"
                className="px-4 py-2 rounded-lg hover:bg-card transition-colors"
                onClick={() => setIsOpen(false)}
              >
                Become a Seller
              </Link>
              {isLoggedIn && (
                <Link
                  href="/wallet"
                  className="px-4 py-2 rounded-lg hover:bg-card transition-colors flex items-center gap-2"
                  onClick={() => setIsOpen(false)}
                >
                  <Wallet className="w-4 h-4" />
                  Wallet: ₹{walletBalance.toFixed(2)}
                </Link>
              )}
              <hr className="my-2 border-border" />
              {!isLoggedIn ? (
                <>
                  <Link
                    href="/login"
                    className="px-4 py-2 rounded-lg border border-primary text-primary text-center hover:bg-primary hover:text-primary-foreground transition-colors"
                    onClick={() => setIsOpen(false)}
                  >
                    Login
                  </Link>
                  <Link
                    href="/register"
                    className="px-4 py-2 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground text-center hover:shadow-lg hover:shadow-primary/50 transition-all"
                    onClick={() => setIsOpen(false)}
                  >
                    Sign Up
                  </Link>
                </>
              ) : (
                <button
                  onClick={handleLogout}
                  className="px-4 py-2 rounded-lg border border-destructive text-destructive hover:bg-destructive/10 transition-colors text-left"
                >
                  Logout
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}

"use client"

import Link from "next/link"
import { ArrowRight, Zap, Lock, TrendingUp } from "lucide-react"

export default function Hero() {
  return (
    <section className="relative min-h-[600px] flex items-center overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-72 h-72 bg-secondary/10 rounded-full blur-3xl animate-pulse delay-700"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8 animate-slide-up">
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-bold leading-tight">
                <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                  Digital Products
                </span>
                <br />
                Marketplace
              </h1>
              <p className="text-lg text-muted-foreground max-w-lg">
                Buy and sell digital products - apps, source codes, AI prompts, tutorials, and more. Built by creators,
                for creators.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                href="/browse"
                className="px-8 py-3 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-medium hover:shadow-lg hover:shadow-primary/50 transition-all duration-200 flex items-center justify-center gap-2 group active:button-click"
              >
                Start Shopping
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                href="/sell"
                className="px-8 py-3 rounded-lg border border-primary text-primary hover:bg-primary/10 font-medium transition-all duration-200"
              >
                Become a Seller
              </Link>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 pt-8">
              <div className="p-4 rounded-lg border border-border/50 bg-card/50">
                <div className="text-2xl font-bold text-primary">1000+</div>
                <div className="text-xs text-muted-foreground">Products</div>
              </div>
              <div className="p-4 rounded-lg border border-border/50 bg-card/50">
                <div className="text-2xl font-bold text-primary">5000+</div>
                <div className="text-xs text-muted-foreground">Users</div>
              </div>
              <div className="p-4 rounded-lg border border-border/50 bg-card/50">
                <div className="text-2xl font-bold text-primary">₹50L+</div>
                <div className="text-xs text-muted-foreground">Sales</div>
              </div>
            </div>
          </div>

          {/* Right Visual */}
          <div className="hidden md:block animate-fade-in">
            <div className="relative w-full aspect-square">
              {/* Feature cards floating */}
              <div className="absolute top-10 right-10 p-4 rounded-lg border border-primary/30 bg-card/50 backdrop-blur-sm space-y-2 animate-bounce delay-100">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium">Instant Downloads</span>
                </div>
              </div>

              <div className="absolute bottom-20 left-10 p-4 rounded-lg border border-secondary/30 bg-card/50 backdrop-blur-sm space-y-2 animate-bounce delay-300">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-secondary" />
                  <span className="text-sm font-medium">Secure Payments</span>
                </div>
              </div>

              <div className="absolute bottom-40 right-20 p-4 rounded-lg border border-accent/30 bg-card/50 backdrop-blur-sm space-y-2 animate-bounce delay-500">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-accent" />
                  <span className="text-sm font-medium">Grow Your Sales</span>
                </div>
              </div>

              {/* Central element */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-48 h-48 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-2xl blur-xl animate-pulse-glow"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

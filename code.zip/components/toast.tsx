"use client"

import { useEffect } from "react"
import { X, CheckCircle, AlertCircle, Info } from "lucide-react"

interface ToastProps {
  message: string
  type: "success" | "error" | "info"
  onClose: () => void
}

export default function Toast({ message, type, onClose }: ToastProps) {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000)
    return () => clearTimeout(timer)
  }, [onClose])

  const bgColor = {
    success: "bg-green-500/20 border-green-500/50",
    error: "bg-red-500/20 border-red-500/50",
    info: "bg-primary/20 border-primary/50",
  }

  const Icon = {
    success: CheckCircle,
    error: AlertCircle,
    info: Info,
  }

  const IconColor = {
    success: "text-green-500",
    error: "text-destructive",
    info: "text-primary",
  }

  const ToastIcon = Icon[type]

  return (
    <div
      className={`fixed bottom-4 right-4 max-w-sm p-4 rounded-lg border ${bgColor[type]} flex items-start gap-3 animate-slide-up`}
    >
      <ToastIcon className={`w-5 h-5 flex-shrink-0 mt-0.5 ${IconColor[type]}`} />
      <p className="flex-1 text-sm">{message}</p>
      <button onClick={onClose} className="flex-shrink-0 text-muted-foreground hover:text-foreground transition-colors">
        <X className="w-4 h-4" />
      </button>
    </div>
  )
}

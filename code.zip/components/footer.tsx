"use client"

import Link from "next/link"
import { Github, Twitter, Mail } from "lucide-react"

export default function Footer() {
  return (
    <footer className="border-t border-border bg-card/50 backdrop-blur-sm mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center font-bold text-primary-foreground text-sm">
                BW
              </div>
              <span className="font-bold">Build With Satya</span>
            </div>
            <p className="text-sm text-muted-foreground">Your ultimate digital products marketplace</p>
          </div>

          {/* Links */}
          <div className="space-y-4">
            <h4 className="font-semibold text-sm">Marketplace</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <Link href="/browse" className="hover:text-primary transition-colors block">
                Browse Products
              </Link>
              <Link href="/categories" className="hover:text-primary transition-colors block">
                Categories
              </Link>
              <Link href="/sellers" className="hover:text-primary transition-colors block">
                Top Sellers
              </Link>
            </div>
          </div>

          {/* Resources */}
          <div className="space-y-4">
            <h4 className="font-semibold text-sm">Resources</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <Link href="/docs" className="hover:text-primary transition-colors block">
                Documentation
              </Link>
              <Link href="/blog" className="hover:text-primary transition-colors block">
                Blog
              </Link>
              <Link href="/support" className="hover:text-primary transition-colors block">
                Support
              </Link>
            </div>
          </div>

          {/* Legal */}
          <div className="space-y-4">
            <h4 className="font-semibold text-sm">Legal</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <Link href="/privacy" className="hover:text-primary transition-colors block">
                Privacy
              </Link>
              <Link href="/terms" className="hover:text-primary transition-colors block">
                Terms
              </Link>
              <Link href="/contact" className="hover:text-primary transition-colors block">
                Contact
              </Link>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-border my-8"></div>

        {/* Bottom */}
        <div className="flex justify-between items-center">
          <p className="text-sm text-muted-foreground">© 2025 Build With Satya. All rights reserved.</p>
          <div className="flex gap-4">
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-primary transition-colors"
            >
              <Twitter className="w-5 h-5" />
            </a>
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-primary transition-colors"
            >
              <Github className="w-5 h-5" />
            </a>
            <a
              href="mailto:contact@bwmstore.com"
              className="text-muted-foreground hover:text-primary transition-colors"
            >
              <Mail className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}

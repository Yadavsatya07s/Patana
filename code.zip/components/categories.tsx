"use client"

import Link from "next/link"
import { Code2, Zap, BookOpen, BarChart3, Palette, Database } from "lucide-react"

const categories = [
  { name: "Source Code", icon: Code2, count: 234 },
  { name: "AI Prompts", icon: Zap, count: 156 },
  { name: "Tutorials", icon: BookOpen, count: 189 },
  { name: "Templates", icon: Palette, count: 267 },
  { name: "Data & APIs", icon: Database, count: 89 },
  { name: "Tools & Apps", icon: BarChart3, count: 145 },
]

export default function Categories() {
  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">Browse by Category</h2>
        <p className="text-muted-foreground max-w-md mx-auto">
          Find the perfect digital products tailored to your needs
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 animate-slide-up">
        {categories.map((category) => {
          const Icon = category.icon
          return (
            <Link
              key={category.name}
              href={`/browse?category=${category.name}`}
              className="group p-6 rounded-lg border border-border hover:border-primary bg-card/50 hover:bg-card transition-all duration-300 hover:shadow-lg hover:shadow-primary/10"
            >
              <div className="flex flex-col items-center text-center gap-3">
                <div className="p-3 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
                  <Icon className="w-6 h-6 text-primary group-hover:scale-110 transition-transform" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm">{category.name}</h3>
                  <p className="text-xs text-muted-foreground">{category.count} items</p>
                </div>
              </div>
            </Link>
          )
        })}
      </div>
    </section>
  )
}

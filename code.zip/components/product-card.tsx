"use client"

import Link from "next/link"
import { Star, ShoppingCart, Download } from "lucide-react"
import { useState } from "react"

interface ProductCardProps {
  product: any
  setToast?: (toast: { message: string; type: "success" | "error" | "info" }) => void
}

export default function ProductCard({ product, setToast }: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <Link href={`/product/${product.id}`}>
      <div
        className="group rounded-lg border border-border bg-card/50 overflow-hidden hover:border-primary transition-all duration-300 hover:shadow-lg hover:shadow-primary/20 cursor-pointer"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Image */}
        <div className="relative h-48 bg-muted overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center text-muted-foreground text-sm">
            {product.category || "Digital Product"}
          </div>
          {isHovered && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center gap-2 animate-fade-in">
              <button className="p-2 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 transition-colors">
                <ShoppingCart className="w-5 h-5" />
              </button>
              <button className="p-2 rounded-full bg-secondary text-secondary-foreground hover:bg-secondary/90 transition-colors">
                <Download className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-4 space-y-2">
          <h3 className="font-semibold text-sm line-clamp-2 group-hover:text-primary transition-colors">
            {product.name}
          </h3>
          <p className="text-xs text-muted-foreground line-clamp-2">{product.description}</p>

          {/* Rating */}
          <div className="flex items-center gap-1 text-xs">
            <div className="flex text-yellow-500">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className={`w-3 h-3 ${i < Math.floor(product.rating || 4) ? "fill-current" : ""}`} />
              ))}
            </div>
            <span className="text-muted-foreground">({product.reviews || 0})</span>
          </div>

          {/* Price and Seller */}
          <div className="flex justify-between items-center pt-2 border-t border-border">
            <span className="text-lg font-bold text-primary">₹{product.price}</span>
            <span className="text-xs text-muted-foreground">{product.seller_name}</span>
          </div>
        </div>
      </div>
    </Link>
  )
}

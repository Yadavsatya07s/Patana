<?php
// Database installation script
// Visit: https://satya.lovestoblog.com/bwmStore/install.php

require_once __DIR__ . '/config.php';

$errors = [];
$success = [];

// Create tables
$tables = [
    "CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        user_type ENUM('buyer', 'seller', 'admin') DEFAULT 'buyer',
        status ENUM('active', 'suspended') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB",
    
    "CREATE TABLE IF NOT EXISTS products (
        id INT PRIMARY KEY AUTO_INCREMENT,
        seller_id INT NOT NULL,
        name VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        full_description LONGTEXT,
        category VARCHAR(100) NOT NULL,
        price DECIMAL(10, 2) NOT NULL,
        features JSON,
        rating DECIMAL(3, 2) DEFAULT 4.0,
        reviews INT DEFAULT 0,
        downloads INT DEFAULT 0,
        status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
        featured BOOLEAN DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE CASCADE,
        KEY (status),
        KEY (category)
    ) ENGINE=InnoDB",
    
    "CREATE TABLE IF NOT EXISTS wallet (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL UNIQUE,
        balance DECIMAL(12, 2) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB",
    
    "CREATE TABLE IF NOT EXISTS wallet_transactions (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        type ENUM('credit', 'debit') NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        description VARCHAR(255),
        status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
        metadata VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        KEY (user_id),
        KEY (created_at)
    ) ENGINE=InnoDB",
    
    "CREATE TABLE IF NOT EXISTS purchases (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        product_id INT NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        download_token VARCHAR(255) UNIQUE,
        status ENUM('completed', 'refunded') DEFAULT 'completed',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
        KEY (user_id),
        KEY (product_id)
    ) ENGINE=InnoDB",
];

foreach ($tables as $sql) {
    if (!$conn->query($sql)) {
        $errors[] = 'Error: ' . $conn->error;
    } else {
        $success[] = 'Table created successfully';
    }
}

// Create demo admin user if not exists
$result = $conn->query("SELECT id FROM users WHERE user_type = 'admin' LIMIT 1");
if (!$result || $result->num_rows === 0) {
    $admin_password = password_hash('admin123', PASSWORD_BCRYPT);
    $conn->query("INSERT INTO users (name, email, password, user_type, status) 
                 VALUES ('Admin', 'admin@bwmstore.com', '$admin_password', 'admin', 'active')");
    $admin_id = $conn->insert_id;
    $conn->query("INSERT INTO wallet (user_id, balance) VALUES ($admin_id, 0)");
    $success[] = 'Demo admin created: admin@bwmstore.com / admin123';
}

// Create demo seller if not exists
$result = $conn->query("SELECT id FROM users WHERE user_type = 'seller' LIMIT 1");
if (!$result || $result->num_rows === 0) {
    $seller_password = password_hash('seller123', PASSWORD_BCRYPT);
    $conn->query("INSERT INTO users (name, email, password, user_type, status) 
                 VALUES ('Demo Seller', 'seller@bwmstore.com', '$seller_password', 'seller', 'active')");
    $seller_id = $conn->insert_id;
    $conn->query("INSERT INTO wallet (user_id, balance) VALUES ($seller_id, 5000)");
    $success[] = 'Demo seller created: seller@bwmstore.com / seller123';
}

// HTML Response
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BWM Store Installation</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif; background: linear-gradient(135deg, #001 0%, #1a1a2e 100%); color: #fff; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .container { max-width: 600px; width: 100%; background: rgba(15, 15, 25, 0.8); border: 1px solid rgba(0, 212, 255, 0.3); border-radius: 12px; padding: 40px; backdrop-filter: blur(10px); }
        h1 { font-size: 28px; margin-bottom: 10px; background: linear-gradient(to right, #00d4ff, #280eff); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .subtitle { color: rgba(255, 255, 255, 0.7); margin-bottom: 30px; }
        .message { padding: 12px 16px; border-radius: 8px; margin-bottom: 10px; border-left: 4px solid; }
        .success { background: rgba(34, 197, 94, 0.1); border-left-color: #22c55e; color: #86efac; }
        .error { background: rgba(239, 68, 68, 0.1); border-left-color: #ef4444; color: #fca5a5; }
        .info { background: rgba(0, 212, 255, 0.1); border-left-color: #00d4ff; color: #06b6d4; margin-top: 20px; padding: 16px; border-radius: 8px; }
        code { background: rgba(0, 0, 0, 0.3); padding: 2px 6px; border-radius: 4px; font-family: 'Courier New', monospace; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 BWM Store Installation</h1>
        <p class="subtitle">Database setup and initialization</p>
        
        <?php if (empty($errors)): ?>
            <div class="message success">✓ Installation completed successfully!</div>
        <?php else: ?>
            <div class="message error">✗ Installation encountered some errors</div>
        <?php endif; ?>
        
        <?php foreach ($success as $msg): ?>
            <div class="message success">✓ <?php echo htmlspecialchars($msg); ?></div>
        <?php endforeach; ?>
        
        <?php foreach ($errors as $msg): ?>
            <div class="message error">✗ <?php echo htmlspecialchars($msg); ?></div>
        <?php endforeach; ?>
        
        <div class="info">
            <strong>Demo Accounts:</strong><br>
            <strong>Admin:</strong> admin@bwmstore.com / admin123<br>
            <strong>Seller:</strong> seller@bwmstore.com / seller123<br>
            <br>
            <strong>Next Steps:</strong><br>
            1. Delete or protect this install.php file<br>
            2. Update database credentials in config.php<br>
            3. Visit the frontend and register or login
        </div>
    </div>
</body>
</html>

<?php
require_once __DIR__ . '/../config.php';

$token = getAuthToken();
$jwt = $token ? verifyJWT($token) : null;

if (!$jwt) {
    http_response_code(401);
    echo response(false, 'Unauthorized');
    exit();
}

$user_id = $jwt['user_id'];
$action = $_GET['action'] ?? 'getBalance';

switch ($action) {
    case 'getBalance':
        getWalletBalance($conn, $user_id);
        break;
    
    case 'addMoney':
        addMoney($conn, $user_id);
        break;
    
    case 'withdraw':
        handleWithdraw($conn, $user_id);
        break;
    
    default:
        getWalletBalance($conn, $user_id);
}

function getWalletBalance($conn, $user_id) {
    $result = $conn->query("SELECT balance FROM wallet WHERE user_id = " . intval($user_id));
    
    if (!$result || $result->num_rows === 0) {
        // Create wallet if not exists
        $conn->query("INSERT INTO wallet (user_id, balance) VALUES (" . intval($user_id) . ", 0)");
        $balance = 0;
    } else {
        $balance = floatval($result->fetch_assoc()['balance']);
    }
    
    // Get transactions
    $trans = $conn->query("SELECT * FROM wallet_transactions WHERE user_id = " . intval($user_id) . " ORDER BY created_at DESC LIMIT 20");
    
    $transactions = [];
    if ($trans) {
        while ($row = $trans->fetch_assoc()) {
            $transactions[] = [
                'id' => $row['id'],
                'type' => $row['type'],
                'amount' => floatval($row['amount']),
                'description' => $row['description'],
                'status' => $row['status'],
                'date' => $row['created_at'],
            ];
        }
    }
    
    http_response_code(200);
    echo response(true, '', [
        'balance' => $balance,
        'transactions' => $transactions,
    ]);
}

function addMoney($conn, $user_id) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    
    $amount = floatval($input['amount'] ?? 0);
    $method = $conn->real_escape_string($input['method'] ?? 'manual_payment');
    
    if ($amount <= 0) {
        http_response_code(400);
        echo response(false, 'Invalid amount');
        return;
    }
    
    // Create pending transaction
    $query = "INSERT INTO wallet_transactions (user_id, type, amount, description, status, created_at)
              VALUES (" . intval($user_id) . ", 'credit', $amount, 'Add money via $method', 'pending', NOW())";
    
    if ($conn->query($query)) {
        http_response_code(200);
        echo response(true, 'Request submitted. Amount will be added after admin verification.');
    } else {
        http_response_code(500);
        echo response(false, 'Failed to process request');
    }
}

function handleWithdraw($conn, $user_id) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    
    $amount = floatval($input['amount'] ?? 0);
    $bank_account = $conn->real_escape_string($input['bank_account'] ?? '');
    
    if ($amount < 100) {
        http_response_code(400);
        echo response(false, 'Minimum withdrawal is ₹100');
        return;
    }
    
    // Get balance
    $result = $conn->query("SELECT balance FROM wallet WHERE user_id = " . intval($user_id));
    if (!$result || $result->num_rows === 0) {
        http_response_code(400);
        echo response(false, 'Wallet not found');
        return;
    }
    
    $balance = floatval($result->fetch_assoc()['balance']);
    
    if ($balance < $amount) {
        http_response_code(400);
        echo response(false, 'Insufficient balance');
        return;
    }
    
    // Create withdrawal request
    $query = "INSERT INTO wallet_transactions (user_id, type, amount, description, status, metadata, created_at)
              VALUES (" . intval($user_id) . ", 'debit', $amount, 'Withdrawal request', 'pending', '$bank_account', NOW())";
    
    if ($conn->query($query)) {
        http_response_code(200);
        echo response(true, 'Withdrawal request submitted');
    } else {
        http_response_code(500);
        echo response(false, 'Failed to process withdrawal');
    }
}

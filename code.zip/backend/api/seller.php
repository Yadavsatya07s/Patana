<?php
require_once __DIR__ . '/../config.php';

$token = getAuthToken();
$jwt = $token ? verifyJWT($token) : null;

if (!$jwt || $jwt['user_type'] !== 'seller') {
    http_response_code(401);
    echo response(false, 'Unauthorized');
    exit();
}

$user_id = $jwt['user_id'];
$action = $_GET['action'] ?? 'dashboard';

switch ($action) {
    case 'dashboard':
        getSellerDashboard($conn, $user_id);
        break;
    
    case 'uploadProduct':
        uploadProduct($conn, $user_id);
        break;
    
    case 'deleteProduct':
        deleteProduct($conn, $user_id);
        break;
    
    default:
        getSellerDashboard($conn, $user_id);
}

function getSellerDashboard($conn, $user_id) {
    $user_id = intval($user_id);
    
    // Get seller products
    $products = [];
    $result = $conn->query("SELECT * FROM products WHERE seller_id = $user_id ORDER BY created_at DESC");
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $products[] = [
                'id' => $row['id'],
                'name' => $row['name'],
                'price' => floatval($row['price']),
                'downloads' => intval($row['downloads']),
                'status' => $row['status'],
                'created_at' => $row['created_at'],
            ];
        }
    }
    
    // Calculate stats
    $stats_result = $conn->query("
        SELECT 
            COUNT(*) as totalProducts,
            SUM(downloads) as totalDownloads,
            SUM(price * downloads * 0.7) as totalEarnings
        FROM products 
        WHERE seller_id = $user_id AND status = 'approved'
    ");
    
    $stats = ['totalProducts' => 0, 'totalDownloads' => 0, 'totalEarnings' => 0, 'totalSales' => 0];
    if ($stats_result) {
        $row = $stats_result->fetch_assoc();
        $stats['totalProducts'] = intval($row['totalProducts']);
        $stats['totalDownloads'] = intval($row['totalDownloads']);
        $stats['totalEarnings'] = floatval($row['totalEarnings'] ?? 0);
        $stats['totalSales'] = $stats['totalProducts'];
    }
    
    http_response_code(200);
    echo response(true, '', [
        'products' => $products,
        'stats' => $stats,
    ]);
}

function uploadProduct($conn, $user_id) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    
    $name = $conn->real_escape_string($input['name'] ?? '');
    $description = $conn->real_escape_string($input['description'] ?? '');
    $full_description = $conn->real_escape_string($input['full_description'] ?? '');
    $category = $conn->real_escape_string($input['category'] ?? '');
    $price = floatval($input['price'] ?? 0);
    $features = $conn->real_escape_string($input['features'] ?? '[]');
    
    if (empty($name) || empty($description) || $price <= 0) {
        http_response_code(400);
        echo response(false, 'Invalid product data');
        return;
    }
    
    $user_id = intval($user_id);
    $status = 'pending'; // Require admin approval
    
    $query = "INSERT INTO products 
              (seller_id, name, description, full_description, category, price, features, status, created_at)
              VALUES ($user_id, '$name', '$description', '$full_description', '$category', $price, '$features', '$status', NOW())";
    
    if ($conn->query($query)) {
        $product_id = $conn->insert_id;
        http_response_code(201);
        echo response(true, 'Product uploaded successfully. Awaiting admin approval.', ['product_id' => $product_id]);
    } else {
        http_response_code(500);
        echo response(false, 'Upload failed: ' . $conn->error);
    }
}

function deleteProduct($conn, $user_id) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    
    $product_id = intval($input['product_id'] ?? 0);
    $user_id = intval($user_id);
    
    if ($product_id === 0) {
        http_response_code(400);
        echo response(false, 'Product ID required');
        return;
    }
    
    // Check ownership
    $check = $conn->query("SELECT id FROM products WHERE id = $product_id AND seller_id = $user_id");
    if (!$check || $check->num_rows === 0) {
        http_response_code(403);
        echo response(false, 'Unauthorized');
        return;
    }
    
    if ($conn->query("DELETE FROM products WHERE id = $product_id")) {
        http_response_code(200);
        echo response(true, 'Product deleted');
    } else {
        http_response_code(500);
        echo response(false, 'Deletion failed');
    }
}

<?php
require_once __DIR__ . '/../config.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true) ?? [];

if (!empty($_POST)) {
    $input = $_POST;
}

// Merge POST and JSON input
$data = array_merge($input, $action ? ['action' => $action] : []);

switch ($data['action'] ?? '') {
    case 'register':
        handleRegister($conn, $data);
        break;
    
    case 'login':
        handleLogin($conn, $data);
        break;
    
    case 'logout':
        http_response_code(200);
        echo response(true, 'Logged out successfully');
        break;
    
    default:
        http_response_code(400);
        echo response(false, 'Invalid action');
}

function handleRegister($conn, $data) {
    $name = $conn->real_escape_string($data['name'] ?? '');
    $email = $conn->real_escape_string($data['email'] ?? '');
    $password = $data['password'] ?? '';
    $user_type = in_array($data['user_type'] ?? '', ['buyer', 'seller']) ? $data['user_type'] : 'buyer';
    
    if (empty($name) || empty($email) || empty($password)) {
        http_response_code(400);
        echo response(false, 'Missing required fields');
        return;
    }
    
    if (strlen($password) < 6) {
        http_response_code(400);
        echo response(false, 'Password must be at least 6 characters');
        return;
    }
    
    // Check if email exists
    $check = $conn->query("SELECT id FROM users WHERE email = '$email'");
    if ($check && $check->num_rows > 0) {
        http_response_code(400);
        echo response(false, 'Email already registered');
        return;
    }
    
    $password_hash = password_hash($password, PASSWORD_BCRYPT);
    
    $query = "INSERT INTO users (name, email, password, user_type, status, created_at) 
              VALUES ('$name', '$email', '$password_hash', '$user_type', 'active', NOW())";
    
    if ($conn->query($query)) {
        $user_id = $conn->insert_id;
        
        // Create wallet for user
        $conn->query("INSERT INTO wallet (user_id, balance, created_at) VALUES ($user_id, 0, NOW())");
        
        http_response_code(201);
        echo response(true, 'Registration successful', [
            'user_id' => $user_id,
            'name' => $name,
            'email' => $email,
        ]);
    } else {
        http_response_code(500);
        echo response(false, 'Registration failed: ' . $conn->error);
    }
}

function handleLogin($conn, $data) {
    $email = $conn->real_escape_string($data['email'] ?? '');
    $password = $data['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        http_response_code(400);
        echo response(false, 'Email and password required');
        return;
    }
    
    $result = $conn->query("SELECT id, name, email, password, user_type, status FROM users WHERE email = '$email'");
    
    if (!$result || $result->num_rows === 0) {
        http_response_code(401);
        echo response(false, 'Invalid email or password');
        return;
    }
    
    $user = $result->fetch_assoc();
    
    if ($user['status'] !== 'active') {
        http_response_code(403);
        echo response(false, 'Account is suspended');
        return;
    }
    
    if (!password_verify($password, $user['password'])) {
        http_response_code(401);
        echo response(false, 'Invalid email or password');
        return;
    }
    
    $token = createJWT($user['id'], $user['user_type']);
    
    http_response_code(200);
    echo response(true, 'Login successful', [
        'token' => $token,
        'user_id' => $user['id'],
        'user_name' => $user['name'],
        'user_type' => $user['user_type'],
    ]);
}

<?php
require_once __DIR__ . '/../config.php';

$token = getAuthToken();
$jwt = $token ? verifyJWT($token) : null;

if (!$jwt || $jwt['user_type'] !== 'admin') {
    http_response_code(401);
    echo response(false, 'Unauthorized');
    exit();
}

$action = $_GET['action'] ?? 'dashboard';

switch ($action) {
    case 'dashboard':
        getDashboard($conn);
        break;
    
    case 'products':
        getProducts($conn);
        break;
    
    case 'approveProduct':
        approveProduct($conn);
        break;
    
    case 'rejectProduct':
        rejectProduct($conn);
        break;
    
    default:
        getDashboard($conn);
}

function getDashboard($conn) {
    // Get stats
    $stats = [
        'totalUsers' => 0,
        'totalSellers' => 0,
        'totalProducts' => 0,
        'totalRevenue' => 0,
        'pendingApprovals' => 0,
        'totalTransactions' => 0,
    ];
    
    // Count users
    $result = $conn->query("SELECT COUNT(*) as count FROM users WHERE user_type = 'buyer'");
    if ($result) $stats['totalUsers'] = intval($result->fetch_assoc()['count']);
    
    // Count sellers
    $result = $conn->query("SELECT COUNT(*) as count FROM users WHERE user_type = 'seller'");
    if ($result) $stats['totalSellers'] = intval($result->fetch_assoc()['count']);
    
    // Count products
    $result = $conn->query("SELECT COUNT(*) as count FROM products WHERE status = 'approved'");
    if ($result) $stats['totalProducts'] = intval($result->fetch_assoc()['count']);
    
    // Count pending approvals
    $result = $conn->query("SELECT COUNT(*) as count FROM products WHERE status = 'pending'");
    if ($result) $stats['pendingApprovals'] = intval($result->fetch_assoc()['count']);
    
    // Get recent activities
    $activities = [];
    $result = $conn->query("
        SELECT 'Product Upload' as title, CONCAT('New product: ', name) as description, created_at as date
        FROM products 
        ORDER BY created_at DESC 
        LIMIT 10
    ");
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $activities[] = $row;
        }
    }
    
    http_response_code(200);
    echo response(true, '', [
        'stats' => $stats,
        'activities' => $activities,
    ]);
}

function getProducts($conn) {
    $status = $conn->real_escape_string($_GET['status'] ?? 'pending');
    
    $products = [];
    $result = $conn->query("
        SELECT p.*, u.name as seller_name 
        FROM products p
        JOIN users u ON p.seller_id = u.id
        WHERE p.status = '$status'
        ORDER BY p.created_at DESC
    ");
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $products[] = [
                'id' => $row['id'],
                'name' => $row['name'],
                'category' => $row['category'],
                'price' => floatval($row['price']),
                'seller_id' => $row['seller_id'],
                'seller_name' => $row['seller_name'],
                'status' => $row['status'],
            ];
        }
    }
    
    http_response_code(200);
    echo response(true, '', ['products' => $products]);
}

function approveProduct($conn) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $product_id = intval($input['product_id'] ?? 0);
    
    if ($product_id === 0) {
        http_response_code(400);
        echo response(false, 'Product ID required');
        return;
    }
    
    if ($conn->query("UPDATE products SET status = 'approved' WHERE id = $product_id")) {
        http_response_code(200);
        echo response(true, 'Product approved');
    } else {
        http_response_code(500);
        echo response(false, 'Failed to approve');
    }
}

function rejectProduct($conn) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $product_id = intval($input['product_id'] ?? 0);
    
    if ($product_id === 0) {
        http_response_code(400);
        echo response(false, 'Product ID required');
        return;
    }
    
    if ($conn->query("UPDATE products SET status = 'rejected' WHERE id = $product_id")) {
        http_response_code(200);
        echo response(true, 'Product rejected');
    } else {
        http_response_code(500);
        echo response(false, 'Failed to reject');
    }
}

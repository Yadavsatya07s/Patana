<?php
require_once __DIR__ . '/../config.php';

$action = $_GET['action'] ?? 'list';
$id = intval($_GET['id'] ?? 0);
$featured = intval($_GET['featured'] ?? 0);
$limit = intval($_GET['limit'] ?? 20);

switch ($action) {
    case 'list':
        listProducts($conn, $featured, $limit);
        break;
    
    case 'get':
        if ($id === 0) {
            http_response_code(400);
            echo response(false, 'Product ID required');
            return;
        }
        getProduct($conn, $id);
        break;
    
    default:
        listProducts($conn, $featured, $limit);
}

function listProducts($conn, $featured = 0, $limit = 20) {
    $where = "WHERE status = 'approved'";
    if ($featured) {
        $where .= " AND featured = 1";
    }
    
    $query = "SELECT * FROM products $where ORDER BY created_at DESC LIMIT $limit";
    $result = $conn->query($query);
    
    $products = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $products[] = formatProduct($row);
        }
    }
    
    http_response_code(200);
    echo response(true, '', ['products' => $products]);
}

function getProduct($conn, $id) {
    $id = intval($id);
    $query = "SELECT * FROM products WHERE id = $id AND status = 'approved'";
    $result = $conn->query($query);
    
    if (!$result || $result->num_rows === 0) {
        http_response_code(404);
        echo response(false, 'Product not found');
        return;
    }
    
    $product = $result->fetch_assoc();
    
    http_response_code(200);
    echo response(true, '', ['product' => formatProduct($product)]);
}

function formatProduct($row) {
    return [
        'id' => $row['id'],
        'name' => $row['name'],
        'description' => $row['description'],
        'full_description' => $row['full_description'],
        'category' => $row['category'],
        'price' => floatval($row['price']),
        'seller_id' => $row['seller_id'],
        'seller_name' => getSeller($row['seller_id'])['name'],
        'rating' => floatval($row['rating']),
        'reviews' => intval($row['reviews']),
        'downloads' => intval($row['downloads']),
        'features' => $row['features'],
        'status' => $row['status'],
        'created_at' => $row['created_at'],
    ];
}

function getSeller($seller_id) {
    global $conn;
    $result = $conn->query("SELECT name FROM users WHERE id = " . intval($seller_id));
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return ['name' => 'Unknown'];
}

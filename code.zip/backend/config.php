<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'bwm_store');

// API Configuration
define('API_BASE_URL', 'https://satya.lovestoblog.com/bwmStore/');
define('JWT_SECRET', 'bwm_store_secret_key_2025_satya');
define('JWT_ALGORITHM', 'HS256');

// File configuration
define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('MAX_FILE_SIZE', 500 * 1024 * 1024); // 500MB

// App configuration
define('APP_NAME', 'BWM Store');
define('APP_TAGLINE', 'Build With Satya | BWM');

// Connect to database
$conn = null;
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        throw new Exception('Database connection failed: ' . $conn->connect_error);
    }
    
    $conn->set_charset('utf8mb4');
} catch (Exception $e) {
    http_response_code(500);
    die(json_encode(['success' => false, 'message' => 'Database error']));
}

// CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// JWT functions
function createJWT($userId, $userType) {
    $header = base64_encode(json_encode(['alg' => JWT_ALGORITHM, 'typ' => 'JWT']));
    $payload = base64_encode(json_encode([
        'user_id' => $userId,
        'user_type' => $userType,
        'iat' => time(),
        'exp' => time() + (30 * 24 * 60 * 60), // 30 days
    ]));
    $signature = base64_encode(hash_hmac('sha256', "$header.$payload", JWT_SECRET, true));
    return "$header.$payload.$signature";
}

function verifyJWT($token) {
    $parts = explode('.', $token);
    if (count($parts) !== 3) return null;
    
    list($header, $payload, $signature) = $parts;
    $valid_signature = base64_encode(hash_hmac('sha256', "$header.$payload", JWT_SECRET, true));
    
    if ($signature !== $valid_signature) return null;
    
    $decoded = json_decode(base64_decode($payload), true);
    if (isset($decoded['exp']) && $decoded['exp'] < time()) return null;
    
    return $decoded;
}

function getAuthToken() {
    $headers = getallheaders();
    if (isset($headers['Authorization'])) {
        $auth = $headers['Authorization'];
        if (strpos($auth, 'Bearer ') === 0) {
            return substr($auth, 7);
        }
    }
    return null;
}

function response($success, $message = '', $data = []) {
    return json_encode(array_merge(['success' => $success, 'message' => $message], $data));
}

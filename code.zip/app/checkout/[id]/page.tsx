"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Navigation from "@/components/navigation"
import Toast from "@/components/toast"
import { ShoppingCart, Check, X } from "lucide-react"
import { API_BASE_URL } from "@/lib/constants"

export default function CheckoutPage() {
  const params = useParams()
  const router = useRouter()
  const [product, setProduct] = useState<any>(null)
  const [walletBalance, setWalletBalance] = useState(0)
  const [loading, setLoading] = useState(true)
  const [processing, setProcessing] = useState(false)
  const [toast, setToast] = useState<any>(null)
  const [theme] = useState<"light" | "dark">("dark")

  useEffect(() => {
    const token = localStorage.getItem("token")
    if (!token) {
      router.push("/login")
      return
    }
    fetchData()
  }, [params.id, router])

  const fetchData = async () => {
    try {
      setLoading(true)
      const token = localStorage.getItem("token")

      // Fetch product
      const productRes = await fetch(`${API_BASE_URL}products.php?id=${params.id}`)
      const productData = await productRes.json()

      // Fetch wallet
      const walletRes = await fetch(`${API_BASE_URL}wallet.php?action=getBalance`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      const walletData = await walletRes.json()

      if (productData.success && walletData.success) {
        setProduct(productData.product)
        setWalletBalance(walletData.balance)
      }
    } catch (error) {
      setToast({ message: "Failed to load data", type: "error" })
    } finally {
      setLoading(false)
    }
  }

  const handlePurchase = async () => {
    if (!product) return

    if (walletBalance < product.price) {
      setToast({ message: "Insufficient wallet balance", type: "error" })
      return
    }

    try {
      setProcessing(true)
      const token = localStorage.getItem("token")
      const response = await fetch(`${API_BASE_URL}purchases.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          action: "purchase",
          product_id: params.id,
          amount: product.price,
        }),
      })

      const data = await response.json()

      if (data.success) {
        setToast({ message: "Purchase successful!", type: "success" })
        const newBalance = walletBalance - product.price
        localStorage.setItem("wallet_balance", newBalance.toString())
        setTimeout(() => router.push(`/downloads/${data.purchase_id}`), 1500)
      } else {
        setToast({ message: data.message || "Purchase failed", type: "error" })
      }
    } catch (error) {
      setToast({ message: "Connection error", type: "error" })
    } finally {
      setProcessing(false)
    }
  }

  if (loading) {
    return (
      <main className="min-h-screen bg-background">
        <Navigation theme={theme} toggleTheme={() => {}} isLoggedIn={true} />
        <div className="max-w-2xl mx-auto px-4 py-12 text-center">
          <div className="animate-pulse">
            <div className="bg-muted h-96 rounded-lg mb-4"></div>
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-background">
      <Navigation theme={theme} toggleTheme={() => {}} isLoggedIn={true} />

      <section className="max-w-2xl mx-auto px-4 py-12">
        <div className="mb-8 animate-slide-down">
          <h1 className="text-4xl font-bold mb-2">Checkout</h1>
          <p className="text-muted-foreground">Complete your purchase</p>
        </div>

        <div className="space-y-6 animate-slide-up">
          {/* Order Summary */}
          <div className="p-6 rounded-lg border border-border bg-card/50 space-y-4">
            <h3 className="font-bold text-lg">Order Summary</h3>

            <div className="flex items-center justify-between p-4 rounded-lg bg-card border border-border/50">
              <div>
                <p className="font-semibold">{product?.name}</p>
                <p className="text-sm text-muted-foreground">{product?.category}</p>
              </div>
              <p className="text-2xl font-bold text-primary">₹{product?.price}</p>
            </div>

            <div className="border-t border-border pt-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-muted-foreground">Subtotal:</span>
                <span className="font-medium">₹{product?.price}</span>
              </div>
              <div className="flex justify-between items-center text-sm text-muted-foreground mb-4">
                <span>Tax:</span>
                <span>₹0</span>
              </div>
              <div className="flex justify-between items-center text-lg font-bold">
                <span>Total:</span>
                <span className="text-primary">₹{product?.price}</span>
              </div>
            </div>
          </div>

          {/* Wallet Status */}
          <div
            className={`p-6 rounded-lg border ${
              walletBalance >= product?.price
                ? "border-green-500/50 bg-green-500/10"
                : "border-red-500/50 bg-red-500/10"
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium">Wallet Balance:</span>
              <span className="text-2xl font-bold">₹{walletBalance.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">After purchase:</span>
              <span
                className={`text-lg font-semibold ${
                  walletBalance >= product?.price ? "text-green-500" : "text-red-500"
                }`}
              >
                ₹{(walletBalance - product?.price).toFixed(2)}
              </span>
            </div>
            {walletBalance < product?.price && (
              <div className="mt-3 p-3 rounded bg-red-500/20 border border-red-500/30 flex items-center gap-2">
                <X className="w-4 h-4 text-red-500" />
                <span className="text-sm">Insufficient balance. Add money to your wallet.</span>
              </div>
            )}
          </div>

          {/* Buttons */}
          <div className="space-y-3">
            <button
              onClick={handlePurchase}
              disabled={processing || walletBalance < product?.price}
              className="w-full px-6 py-3 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-medium hover:shadow-lg hover:shadow-primary/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 active:button-click"
            >
              <ShoppingCart className="w-5 h-5" />
              {processing ? "Processing..." : "Complete Purchase"}
            </button>
            <button
              onClick={() => router.back()}
              className="w-full px-6 py-3 rounded-lg border border-border hover:border-primary hover:bg-card transition-colors"
            >
              Cancel
            </button>
          </div>

          {/* Security Badge */}
          <div className="text-center text-xs text-muted-foreground flex items-center justify-center gap-1">
            <Check className="w-4 h-4 text-green-500" />
            Secure payment processed through BWM Store wallet
          </div>
        </div>
      </section>

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </main>
  )
}

"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import Navigation from "@/components/navigation"
import Toast from "@/components/toast"
import { Download, ShoppingCart, Star, User, Calendar, FileText, CheckCircle } from "lucide-react"
import { API_BASE_URL } from "@/lib/constants"

export default function ProductDetailPage() {
  const params = useParams()
  const router = useRouter()
  const [product, setProduct] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [toast, setToast] = useState<any>(null)
  const [theme] = useState<"light" | "dark">("dark")
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  useEffect(() => {
    setIsLoggedIn(!!localStorage.getItem("token"))
    fetchProduct()
  }, [params.id])

  const fetchProduct = async () => {
    try {
      setLoading(true)
      const response = await fetch(`${API_BASE_URL}products.php?id=${params.id}`)
      const data = await response.json()
      if (data.success && data.product) {
        setProduct(data.product)
      }
    } catch (error) {
      setToast({ message: "Failed to load product", type: "error" })
    } finally {
      setLoading(false)
    }
  }

  const handleBuyClick = () => {
    if (!isLoggedIn) {
      setToast({ message: "Please login to buy products", type: "info" })
      router.push("/login")
      return
    }
    router.push(`/checkout/${params.id}`)
  }

  if (loading) {
    return (
      <main className="min-h-screen bg-background">
        <Navigation theme={theme} toggleTheme={() => {}} isLoggedIn={isLoggedIn} />
        <div className="max-w-4xl mx-auto px-4 py-12 text-center">
          <div className="animate-pulse">
            <div className="bg-muted h-96 rounded-lg mb-4"></div>
            <div className="bg-muted h-8 rounded mb-4 w-1/2 mx-auto"></div>
            <div className="bg-muted h-4 rounded w-2/3 mx-auto"></div>
          </div>
        </div>
      </main>
    )
  }

  if (!product) {
    return (
      <main className="min-h-screen bg-background">
        <Navigation theme={theme} toggleTheme={() => {}} isLoggedIn={isLoggedIn} />
        <div className="max-w-4xl mx-auto px-4 py-12 text-center">
          <p className="text-muted-foreground mb-4">Product not found</p>
          <Link href="/browse" className="text-primary hover:underline">
            Back to products
          </Link>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-background">
      <Navigation theme={theme} toggleTheme={() => {}} isLoggedIn={isLoggedIn} />

      <section className="max-w-6xl mx-auto px-4 py-12">
        {/* Breadcrumb */}
        <div className="flex gap-2 mb-8 text-sm animate-slide-down">
          <Link href="/browse" className="text-primary hover:underline">
            Products
          </Link>
          <span className="text-muted-foreground">/</span>
          <span className="text-muted-foreground truncate">{product.name}</span>
        </div>

        <div className="grid md:grid-cols-2 gap-12 animate-slide-up">
          {/* Product Image/Preview */}
          <div className="rounded-lg border border-border bg-card/50 h-96 flex items-center justify-center">
            <div className="text-center">
              <div className="w-24 h-24 mx-auto mb-4 rounded-lg bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                <FileText className="w-12 h-12 text-primary" />
              </div>
              <p className="text-muted-foreground">{product.category}</p>
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            {/* Title */}
            <div>
              <h1 className="text-4xl font-bold mb-2">{product.name}</h1>
              <p className="text-lg text-muted-foreground">{product.description}</p>
            </div>

            {/* Rating */}
            <div className="flex items-center gap-4">
              <div className="flex text-yellow-500">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className={`w-5 h-5 ${i < Math.floor(product.rating || 4) ? "fill-current" : ""}`} />
                ))}
              </div>
              <span className="text-sm text-muted-foreground">
                {product.rating || 4} stars ({product.reviews || 0} reviews)
              </span>
            </div>

            {/* Price */}
            <div className="text-5xl font-bold text-primary">₹{product.price}</div>

            {/* Features */}
            <div className="space-y-2">
              {product.features &&
                JSON.parse(product.features || "[]").map((feature: string, i: number) => (
                  <div key={i} className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span>{feature}</span>
                  </div>
                ))}
            </div>

            {/* Seller Info */}
            <div className="p-4 rounded-lg border border-border bg-card/50 space-y-2">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-primary" />
                <span className="font-medium">{product.seller_name}</span>
              </div>
              <p className="text-sm text-muted-foreground">
                {product.downloads || 0} downloads • Member since {new Date(product.created_at).getFullYear()}
              </p>
            </div>

            {/* Buttons */}
            <div className="space-y-3">
              <button
                onClick={handleBuyClick}
                className="w-full px-6 py-3 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-medium hover:shadow-lg hover:shadow-primary/50 transition-all flex items-center justify-center gap-2 active:button-click"
              >
                <ShoppingCart className="w-5 h-5" />
                Buy Now
              </button>
              <button className="w-full px-6 py-3 rounded-lg border border-primary text-primary hover:bg-primary/10 font-medium transition-colors flex items-center justify-center gap-2">
                <Download className="w-5 h-5" />
                Free Preview
              </button>
            </div>

            {/* Additional Info */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Category</p>
                <p className="font-medium">{product.category}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Published</p>
                <p className="font-medium flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  {new Date(product.created_at).toLocaleDateString()}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details */}
        <div className="mt-16 p-8 rounded-lg border border-border bg-card/50 animate-slide-up">
          <h2 className="text-2xl font-bold mb-4">About This Product</h2>
          <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
            {product.full_description || product.description}
          </p>
        </div>
      </section>

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </main>
  )
}

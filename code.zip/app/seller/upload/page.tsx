"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Navigation from "@/components/navigation"
import Toast from "@/components/toast"
import { Upload, Plus, X } from "lucide-react"
import { API_BASE_URL } from "@/lib/constants"

const categories = ["Source Code", "AI Prompts", "Tutorials", "Templates", "Data & APIs", "Tools & Apps"]

export default function ProductUploadPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    full_description: "",
    category: categories[0],
    price: "",
    features: [""],
  })
  const [loading, setLoading] = useState(false)
  const [toast, setToast] = useState<any>(null)
  const [theme] = useState<"light" | "dark">("dark")

  useEffect(() => {
    const token = localStorage.getItem("token")
    const userType = localStorage.getItem("user_type")

    if (!token || userType !== "seller") {
      router.push("/login")
    }
  }, [router])

  const handleAddFeature = () => {
    setFormData({ ...formData, features: [...formData.features, ""] })
  }

  const handleRemoveFeature = (index: number) => {
    setFormData({
      ...formData,
      features: formData.features.filter((_, i) => i !== index),
    })
  }

  const handleFeatureChange = (index: number, value: string) => {
    const newFeatures = [...formData.features]
    newFeatures[index] = value
    setFormData({ ...formData, features: newFeatures })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.name || !formData.description || !formData.price) {
      setToast({ message: "Please fill all required fields", type: "error" })
      return
    }

    try {
      setLoading(true)
      const token = localStorage.getItem("token")
      const response = await fetch(`${API_BASE_URL}seller.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          action: "uploadProduct",
          ...formData,
          price: Number(formData.price),
          features: JSON.stringify(formData.features.filter((f) => f)),
        }),
      })

      const data = await response.json()

      if (data.success) {
        setToast({ message: "Product uploaded successfully!", type: "success" })
        setTimeout(() => router.push("/seller/dashboard"), 1500)
      } else {
        setToast({ message: data.message || "Upload failed", type: "error" })
      }
    } catch (error) {
      setToast({ message: "Connection error", type: "error" })
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-background">
      <Navigation theme={theme} toggleTheme={() => {}} isLoggedIn={true} />

      <section className="max-w-4xl mx-auto px-4 py-12">
        <div className="mb-8 animate-slide-down">
          <h1 className="text-4xl font-bold mb-2">Upload Product</h1>
          <p className="text-muted-foreground">Share your digital product with the community</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6 animate-slide-up">
          {/* Product Name */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Product Name *</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="E.g., React Dashboard Template"
              className="w-full px-4 py-2 rounded-lg border border-border bg-card focus:border-primary focus:outline-none transition-colors"
            />
          </div>

          {/* Category */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Category *</label>
            <select
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              className="w-full px-4 py-2 rounded-lg border border-border bg-card focus:border-primary focus:outline-none transition-colors"
            >
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Short Description */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Short Description *</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Brief description for product listings"
              rows={3}
              className="w-full px-4 py-2 rounded-lg border border-border bg-card focus:border-primary focus:outline-none transition-colors resize-none"
            />
          </div>

          {/* Full Description */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Full Description</label>
            <textarea
              value={formData.full_description}
              onChange={(e) => setFormData({ ...formData, full_description: e.target.value })}
              placeholder="Detailed description for product detail page"
              rows={5}
              className="w-full px-4 py-2 rounded-lg border border-border bg-card focus:border-primary focus:outline-none transition-colors resize-none"
            />
          </div>

          {/* Price */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Price (₹) *</label>
            <input
              type="number"
              value={formData.price}
              onChange={(e) => setFormData({ ...formData, price: e.target.value })}
              placeholder="0"
              min="0"
              className="w-full px-4 py-2 rounded-lg border border-border bg-card focus:border-primary focus:outline-none transition-colors"
            />
          </div>

          {/* Features */}
          <div className="space-y-3">
            <label className="text-sm font-medium">Features</label>
            <div className="space-y-2">
              {formData.features.map((feature, index) => (
                <div key={index} className="flex gap-2">
                  <input
                    type="text"
                    value={feature}
                    onChange={(e) => handleFeatureChange(index, e.target.value)}
                    placeholder={`Feature ${index + 1}`}
                    className="flex-1 px-4 py-2 rounded-lg border border-border bg-card focus:border-primary focus:outline-none transition-colors"
                  />
                  {formData.features.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveFeature(index)}
                      className="p-2 rounded-lg border border-border text-destructive hover:bg-destructive/10 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
            <button
              type="button"
              onClick={handleAddFeature}
              className="flex items-center gap-2 px-4 py-2 rounded-lg border border-dashed border-border text-primary hover:border-primary transition-colors"
            >
              <Plus className="w-4 h-4" />
              Add Feature
            </button>
          </div>

          {/* File Upload */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Product File</label>
            <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer">
              <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
              <p className="font-medium mb-1">Upload your product file</p>
              <p className="text-xs text-muted-foreground">ZIP, RAR, or individual files (Max 500MB)</p>
              <input type="file" className="hidden" />
            </div>
          </div>

          {/* Submit */}
          <div className="space-y-3 pt-4">
            <button
              type="submit"
              disabled={loading}
              className="w-full px-6 py-3 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-medium hover:shadow-lg hover:shadow-primary/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed active:button-click"
            >
              {loading ? "Uploading..." : "Upload Product"}
            </button>
            <button
              type="button"
              onClick={() => router.back()}
              className="w-full px-6 py-3 rounded-lg border border-border hover:border-primary hover:bg-card transition-colors"
            >
              Cancel
            </button>
          </div>

          <div className="p-4 rounded-lg bg-card/50 border border-border/50 text-sm text-muted-foreground">
            <p className="font-medium mb-2">Note:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>Your product will be reviewed by our team before publishing</li>
              <li>Approval typically takes 24-48 hours</li>
              <li>Make sure your product meets our quality standards</li>
            </ul>
          </div>
        </form>
      </section>

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </main>
  )
}

"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Navigation from "@/components/navigation"
import Toast from "@/components/toast"
import { BarChart3, Package, TrendingUp, DollarSign, Plus, Eye, Edit, Trash2, Clock } from "lucide-react"
import { API_BASE_URL } from "@/lib/constants"

interface SellerProduct {
  id: number
  name: string
  price: number
  downloads: number
  status: "approved" | "pending" | "rejected"
  created_at: string
}

export default function SellerDashboard() {
  const router = useRouter()
  const [products, setProducts] = useState<SellerProduct[]>([])
  const [stats, setStats] = useState({ totalSales: 0, totalEarnings: 0, totalDownloads: 0, totalProducts: 0 })
  const [loading, setLoading] = useState(true)
  const [toast, setToast] = useState<any>(null)
  const [theme] = useState<"light" | "dark">("dark")

  useEffect(() => {
    const token = localStorage.getItem("token")
    const userType = localStorage.getItem("user_type")

    if (!token || userType !== "seller") {
      router.push("/login")
      return
    }

    fetchSellerData()
  }, [router])

  const fetchSellerData = async () => {
    try {
      setLoading(true)
      const token = localStorage.getItem("token")
      const response = await fetch(`${API_BASE_URL}seller.php?action=dashboard`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await response.json()
      if (data.success) {
        setProducts(data.products || [])
        setStats(data.stats || {})
      }
    } catch (error) {
      setToast({ message: "Failed to load dashboard", type: "error" })
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (productId: number) => {
    if (!confirm("Are you sure you want to delete this product?")) return

    try {
      const token = localStorage.getItem("token")
      const response = await fetch(`${API_BASE_URL}seller.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ action: "deleteProduct", product_id: productId }),
      })

      const data = await response.json()
      if (data.success) {
        setToast({ message: "Product deleted", type: "success" })
        fetchSellerData()
      }
    } catch (error) {
      setToast({ message: "Failed to delete product", type: "error" })
    }
  }

  return (
    <main className="min-h-screen bg-background">
      <Navigation theme={theme} toggleTheme={() => {}} isLoggedIn={true} />

      <section className="max-w-7xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="flex justify-between items-center mb-8 animate-slide-down">
          <div>
            <h1 className="text-4xl font-bold mb-2">Seller Dashboard</h1>
            <p className="text-muted-foreground">Manage your products and earnings</p>
          </div>
          <Link
            href="/seller/upload"
            className="px-6 py-3 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-medium hover:shadow-lg hover:shadow-primary/50 transition-all flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Upload Product
          </Link>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8 animate-slide-up">
          <div className="p-6 rounded-lg border border-border bg-card/50 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground text-sm">Total Sales</span>
              <DollarSign className="w-5 h-5 text-primary" />
            </div>
            <p className="text-3xl font-bold">{stats.totalSales || 0}</p>
            <p className="text-xs text-muted-foreground">₹{stats.totalEarnings?.toFixed(2) || 0}</p>
          </div>

          <div className="p-6 rounded-lg border border-border bg-card/50 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground text-sm">Products</span>
              <Package className="w-5 h-5 text-secondary" />
            </div>
            <p className="text-3xl font-bold">{stats.totalProducts || 0}</p>
            <p className="text-xs text-muted-foreground">Active products</p>
          </div>

          <div className="p-6 rounded-lg border border-border bg-card/50 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground text-sm">Downloads</span>
              <TrendingUp className="w-5 h-5 text-accent" />
            </div>
            <p className="text-3xl font-bold">{stats.totalDownloads || 0}</p>
            <p className="text-xs text-muted-foreground">Total downloads</p>
          </div>

          <div className="p-6 rounded-lg border border-border bg-card/50 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground text-sm">Revenue</span>
              <BarChart3 className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-3xl font-bold text-green-500">₹{(stats.totalEarnings || 0).toFixed(0)}</p>
            <p className="text-xs text-muted-foreground">This month</p>
          </div>
        </div>

        {/* Products List */}
        <div className="p-6 rounded-lg border border-border bg-card/50 animate-slide-up">
          <h2 className="text-2xl font-bold mb-6">Your Products</h2>

          {loading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-20 bg-muted rounded-lg animate-pulse"></div>
              ))}
            </div>
          ) : products.length > 0 ? (
            <div className="space-y-3 overflow-x-auto">
              {products.map((product) => (
                <div
                  key={product.id}
                  className="flex items-center justify-between p-4 rounded-lg border border-border/50 hover:border-border transition-colors"
                >
                  <div className="flex-1">
                    <h3 className="font-semibold mb-1">{product.name}</h3>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>₹{product.price}</span>
                      <span>{product.downloads} downloads</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(product.created_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap justify-end">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        product.status === "approved"
                          ? "bg-green-500/10 text-green-500"
                          : product.status === "pending"
                            ? "bg-yellow-500/10 text-yellow-500"
                            : "bg-red-500/10 text-red-500"
                      }`}
                    >
                      {product.status}
                    </span>

                    <button className="p-2 rounded-lg border border-border hover:border-primary hover:bg-card transition-colors">
                      <Eye className="w-4 h-4 text-primary" />
                    </button>
                    <Link
                      href={`/seller/edit/${product.id}`}
                      className="p-2 rounded-lg border border-border hover:border-primary hover:bg-card transition-colors"
                    >
                      <Edit className="w-4 h-4 text-primary" />
                    </Link>
                    <button
                      onClick={() => handleDelete(product.id)}
                      className="p-2 rounded-lg border border-border hover:border-destructive hover:bg-card transition-colors"
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Package className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground mb-4">No products yet</p>
              <Link
                href="/seller/upload"
                className="inline-flex px-6 py-2 rounded-lg border border-primary text-primary hover:bg-primary/10 font-medium transition-colors"
              >
                Upload Your First Product
              </Link>
            </div>
          )}
        </div>
      </section>

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </main>
  )
}

"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import Navigation from "@/components/navigation"
import ProductCard from "@/components/product-card"
import Toast from "@/components/toast"
import { Search, Filter, ChevronDown } from "lucide-react"
import { API_BASE_URL } from "@/lib/constants"

const categories = ["All", "Source Code", "AI Prompts", "Tutorials", "Templates", "Data & APIs", "Tools & Apps"]
const sortOptions = ["Most Recent", "Price: Low to High", "Price: High to Low", "Most Popular", "Top Rated"]

export default function BrowsePage() {
  const searchParams = useSearchParams()
  const [products, setProducts] = useState([])
  const [filteredProducts, setFilteredProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [priceRange, setPriceRange] = useState({ min: 0, max: 10000 })
  const [sortBy, setSortBy] = useState("Most Recent")
  const [showFilters, setShowFilters] = useState(false)
  const [toast, setToast] = useState<any>(null)
  const [theme] = useState<"light" | "dark">("dark")

  useEffect(() => {
    const category = searchParams.get("category")
    if (category) setSelectedCategory(category)
    fetchProducts()
  }, [searchParams])

  useEffect(() => {
    filterAndSortProducts()
  }, [products, searchTerm, selectedCategory, priceRange, sortBy])

  const fetchProducts = async () => {
    try {
      setLoading(true)
      const response = await fetch(`${API_BASE_URL}products.php`)
      const data = await response.json()
      if (data.success) {
        setProducts(data.products || [])
      }
    } catch (error) {
      setToast({ message: "Failed to load products", type: "error" })
    } finally {
      setLoading(false)
    }
  }

  const filterAndSortProducts = () => {
    const filtered = products.filter((product: any) => {
      const matchesSearch =
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.description.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesCategory = selectedCategory === "All" || product.category === selectedCategory
      const matchesPrice = product.price >= priceRange.min && product.price <= priceRange.max
      return matchesSearch && matchesCategory && matchesPrice
    })

    // Sort
    if (sortBy === "Price: Low to High") {
      filtered.sort((a, b) => a.price - b.price)
    } else if (sortBy === "Price: High to Low") {
      filtered.sort((a, b) => b.price - a.price)
    } else if (sortBy === "Top Rated") {
      filtered.sort((a, b) => (b.rating || 0) - (a.rating || 0))
    } else if (sortBy === "Most Popular") {
      filtered.sort((a, b) => (b.downloads || 0) - (a.downloads || 0))
    }

    setFilteredProducts(filtered)
  }

  return (
    <main className="min-h-screen bg-background">
      <Navigation theme={theme} toggleTheme={() => {}} isLoggedIn={!!localStorage.getItem("token")} />

      <section className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 animate-slide-down">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Browse Products</h1>
          <p className="text-muted-foreground">Discover amazing digital products</p>
        </div>

        {/* Search Bar */}
        <div className="mb-8 space-y-4 animate-slide-down">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-lg border border-border bg-card focus:border-primary focus:outline-none transition-colors"
            />
          </div>

          {/* Mobile Filters Toggle */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="md:hidden w-full px-4 py-2 rounded-lg border border-border hover:border-primary flex items-center justify-center gap-2 transition-colors"
          >
            <Filter className="w-4 h-4" />
            <span>Filters</span>
            <ChevronDown className={`w-4 h-4 transition-transform ${showFilters ? "rotate-180" : ""}`} />
          </button>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div
            className={`md:col-span-1 space-y-6 ${showFilters ? "animate-slide-down" : "hidden md:block"} animate-slide-up`}
          >
            {/* Categories */}
            <div className="p-4 rounded-lg border border-border bg-card/50 space-y-3">
              <h3 className="font-semibold">Category</h3>
              <div className="space-y-2">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                      selectedCategory === cat ? "bg-primary text-primary-foreground" : "hover:bg-card"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range */}
            <div className="p-4 rounded-lg border border-border bg-card/50 space-y-3">
              <h3 className="font-semibold">Price Range</h3>
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-muted-foreground">Min: ₹{priceRange.min}</label>
                  <input
                    type="range"
                    min="0"
                    max="10000"
                    value={priceRange.min}
                    onChange={(e) => setPriceRange({ ...priceRange, min: Number(e.target.value) })}
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Max: ₹{priceRange.max}</label>
                  <input
                    type="range"
                    min="0"
                    max="10000"
                    value={priceRange.max}
                    onChange={(e) => setPriceRange({ ...priceRange, max: Number(e.target.value) })}
                    className="w-full"
                  />
                </div>
              </div>
            </div>

            {/* Sort */}
            <div className="p-4 rounded-lg border border-border bg-card/50 space-y-3">
              <h3 className="font-semibold">Sort By</h3>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-border bg-card focus:border-primary focus:outline-none transition-colors"
              >
                {sortOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Products Grid */}
          <div className="md:col-span-3">
            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-muted h-48 rounded-lg mb-4"></div>
                    <div className="bg-muted h-4 rounded mb-2"></div>
                    <div className="bg-muted h-4 rounded w-3/4"></div>
                  </div>
                ))}
              </div>
            ) : filteredProducts.length > 0 ? (
              <div>
                <div className="mb-4 text-sm text-muted-foreground">
                  Showing {filteredProducts.length} of {products.length} products
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 animate-slide-up">
                  {filteredProducts.map((product: any) => (
                    <ProductCard key={product.id} product={product} setToast={setToast} />
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground mb-4">No products found</p>
                <button
                  onClick={() => {
                    setSearchTerm("")
                    setSelectedCategory("All")
                    setPriceRange({ min: 0, max: 10000 })
                  }}
                  className="px-4 py-2 rounded-lg border border-primary text-primary hover:bg-primary/10 transition-colors"
                >
                  Reset Filters
                </button>
              </div>
            )}
          </div>
        </div>
      </section>

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </main>
  )
}

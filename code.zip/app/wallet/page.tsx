"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Navigation from "@/components/navigation"
import Toast from "@/components/toast"
import { Wallet, Plus, Upload, TrendingUp, History, QrCode } from "lucide-react"
import { API_BASE_URL } from "@/lib/constants"

interface Transaction {
  id: number
  type: "credit" | "debit"
  amount: number
  description: string
  date: string
  status: "completed" | "pending"
}

export default function WalletPage() {
  const router = useRouter()
  const [walletBalance, setWalletBalance] = useState(0)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddMoney, setShowAddMoney] = useState(false)
  const [addMoneyTab, setAddMoneyTab] = useState<"manual" | "qr">("manual")
  const [amount, setAmount] = useState("")
  const [toast, setToast] = useState<any>(null)
  const [theme] = useState<"light" | "dark">("dark")

  useEffect(() => {
    const token = localStorage.getItem("token")
    if (!token) {
      router.push("/login")
      return
    }
    fetchWalletData()
  }, [router])

  const fetchWalletData = async () => {
    try {
      setLoading(true)
      const token = localStorage.getItem("token")
      const response = await fetch(`${API_BASE_URL}wallet.php?action=getBalance`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await response.json()
      if (data.success) {
        setWalletBalance(data.balance)
        setTransactions(data.transactions || [])
        localStorage.setItem("wallet_balance", data.balance.toString())
      }
    } catch (error) {
      setToast({ message: "Failed to load wallet data", type: "error" })
    } finally {
      setLoading(false)
    }
  }

  const handleAddMoney = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!amount || Number(amount) <= 0) {
      setToast({ message: "Enter a valid amount", type: "error" })
      return
    }

    try {
      const token = localStorage.getItem("token")
      const response = await fetch(`${API_BASE_URL}wallet.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          action: "addMoney",
          amount: Number(amount),
          method: addMoneyTab === "manual" ? "manual_payment" : "qr_upload",
        }),
      })

      const data = await response.json()

      if (data.success) {
        setToast({ message: "Money added successfully!", type: "success" })
        setAmount("")
        setShowAddMoney(false)
        fetchWalletData()
      } else {
        setToast({ message: data.message || "Failed to add money", type: "error" })
      }
    } catch (error) {
      setToast({ message: "Connection error", type: "error" })
    }
  }

  return (
    <main className="min-h-screen bg-background">
      <Navigation theme={theme} toggleTheme={() => {}} isLoggedIn={true} />

      <section className="max-w-4xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="mb-8 animate-slide-down">
          <h1 className="text-4xl font-bold mb-2">My Wallet</h1>
          <p className="text-muted-foreground">Manage your account balance and transactions</p>
        </div>

        {/* Balance Card */}
        <div className="p-8 rounded-lg border border-border bg-gradient-to-br from-primary/10 to-secondary/10 mb-8 animate-slide-up">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-muted-foreground mb-2">Total Balance</p>
              <h2 className="text-5xl font-bold text-primary">₹{walletBalance.toFixed(2)}</h2>
            </div>
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
              <Wallet className="w-10 h-10 text-primary-foreground" />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3 mt-6">
            <button
              onClick={() => setShowAddMoney(!showAddMoney)}
              className="px-4 py-2 rounded-lg border border-primary text-primary hover:bg-primary/10 font-medium transition-colors flex items-center justify-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Add Money
            </button>
            <button className="px-4 py-2 rounded-lg border border-accent text-accent hover:bg-accent/10 font-medium transition-colors flex items-center justify-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Withdraw
            </button>
          </div>
        </div>

        {/* Add Money Form */}
        {showAddMoney && (
          <div className="p-6 rounded-lg border border-border bg-card mb-8 animate-slide-down">
            <h3 className="text-xl font-bold mb-4">Add Money to Wallet</h3>

            {/* Tab Selection */}
            <div className="flex gap-2 mb-6">
              <button
                onClick={() => setAddMoneyTab("manual")}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  addMoneyTab === "manual"
                    ? "bg-primary text-primary-foreground"
                    : "border border-border hover:border-primary"
                }`}
              >
                Manual Payment
              </button>
              <button
                onClick={() => setAddMoneyTab("qr")}
                className={`px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2 ${
                  addMoneyTab === "qr"
                    ? "bg-primary text-primary-foreground"
                    : "border border-border hover:border-primary"
                }`}
              >
                <QrCode className="w-4 h-4" />
                QR Upload
              </button>
            </div>

            <form onSubmit={handleAddMoney} className="space-y-4">
              {/* Amount */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Amount (₹)</label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Enter amount"
                  className="w-full px-4 py-2 rounded-lg border border-border bg-card focus:border-primary focus:outline-none transition-colors"
                />
              </div>

              {/* Manual Payment Instructions */}
              {addMoneyTab === "manual" && (
                <div className="p-4 rounded-lg bg-card/50 border border-border/50 space-y-2">
                  <h4 className="font-medium text-sm mb-3">Payment Instructions:</h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    1. Transfer the amount to our bank account
                    <br />
                    2. Screenshot your transaction
                    <br />
                    3. Submit the transaction ID below
                    <br />
                    4. Amount will be added after verification (24 hours)
                  </p>
                  <input
                    type="text"
                    placeholder="Transaction ID (optional)"
                    className="w-full px-3 py-2 rounded-lg border border-border bg-card text-xs focus:border-primary focus:outline-none transition-colors mt-3"
                  />
                </div>
              )}

              {/* QR Upload */}
              {addMoneyTab === "qr" && (
                <div className="p-4 rounded-lg bg-card/50 border border-border/50 space-y-3">
                  <label className="block">
                    <div className="border-2 border-dashed border-border rounded-lg p-6 text-center cursor-pointer hover:border-primary transition-colors">
                      <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-sm font-medium">Upload QR Payment Screenshot</p>
                      <p className="text-xs text-muted-foreground mt-1">JPG, PNG (Max 5MB)</p>
                    </div>
                    <input type="file" accept="image/*" className="hidden" />
                  </label>
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full px-4 py-2 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-medium hover:shadow-lg hover:shadow-primary/50 transition-all active:button-click"
              >
                Proceed
              </button>
            </form>

            <button
              onClick={() => setShowAddMoney(false)}
              className="w-full mt-3 px-4 py-2 rounded-lg border border-border hover:bg-card transition-colors"
            >
              Cancel
            </button>
          </div>
        )}

        {/* Transaction History */}
        <div className="p-6 rounded-lg border border-border bg-card/50">
          <div className="flex items-center gap-2 mb-6">
            <History className="w-5 h-5 text-primary" />
            <h3 className="text-xl font-bold">Transaction History</h3>
          </div>

          {loading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-16 bg-muted rounded-lg animate-pulse"></div>
              ))}
            </div>
          ) : transactions.length > 0 ? (
            <div className="space-y-3">
              {transactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="p-4 rounded-lg border border-border/50 hover:border-border flex items-center justify-between transition-colors animate-slide-up"
                >
                  <div className="flex-1">
                    <p className="font-medium">{transaction.description}</p>
                    <p className="text-xs text-muted-foreground">{new Date(transaction.date).toLocaleDateString()}</p>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold ${transaction.type === "credit" ? "text-green-500" : "text-red-500"}`}>
                      {transaction.type === "credit" ? "+" : "-"}₹{transaction.amount}
                    </p>
                    <span
                      className={`text-xs px-2 py-1 rounded ${
                        transaction.status === "completed"
                          ? "bg-green-500/10 text-green-500"
                          : "bg-yellow-500/10 text-yellow-500"
                      }`}
                    >
                      {transaction.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No transactions yet</p>
            </div>
          )}
        </div>
      </section>

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </main>
  )
}

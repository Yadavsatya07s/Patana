"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Navigation from "@/components/navigation"
import Toast from "@/components/toast"
import { Users, Package, DollarSign, TrendingUp, BarChart3, AlertCircle } from "lucide-react"
import { API_BASE_URL } from "@/lib/constants"

export default function AdminDashboard() {
  const router = useRouter()
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalSellers: 0,
    totalProducts: 0,
    totalRevenue: 0,
    pendingApprovals: 0,
    totalTransactions: 0,
  })
  const [recentActivities, setRecentActivities] = useState([])
  const [loading, setLoading] = useState(true)
  const [toast, setToast] = useState<any>(null)
  const [theme] = useState<"light" | "dark">("dark")

  useEffect(() => {
    const token = localStorage.getItem("token")
    const userType = localStorage.getItem("user_type")

    if (!token || userType !== "admin") {
      router.push("/login")
      return
    }

    fetchAdminData()
  }, [router])

  const fetchAdminData = async () => {
    try {
      setLoading(true)
      const token = localStorage.getItem("token")
      const response = await fetch(`${API_BASE_URL}admin.php?action=dashboard`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await response.json()
      if (data.success) {
        setStats(data.stats || {})
        setRecentActivities(data.activities || [])
      }
    } catch (error) {
      setToast({ message: "Failed to load dashboard", type: "error" })
    } finally {
      setLoading(false)
    }
  }

  const StatCard = ({ icon: Icon, label, value, subtext, color }: any) => (
    <div className="p-6 rounded-lg border border-border bg-card/50 space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-muted-foreground text-sm">{label}</span>
        <div className={`p-2 rounded-lg ${color}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
      <p className="text-3xl font-bold">{value}</p>
      <p className="text-xs text-muted-foreground">{subtext}</p>
    </div>
  )

  return (
    <main className="min-h-screen bg-background">
      <Navigation theme={theme} toggleTheme={() => {}} isLoggedIn={true} />

      <section className="max-w-7xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="mb-8 animate-slide-down">
          <h1 className="text-4xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-muted-foreground">Platform analytics and management</p>
        </div>

        {/* Key Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8 animate-slide-up">
          <StatCard
            icon={Users}
            label="Total Users"
            value={stats.totalUsers}
            subtext={`${stats.totalSellers} sellers`}
            color="bg-primary/20"
          />
          <StatCard
            icon={Package}
            label="Total Products"
            value={stats.totalProducts}
            subtext={`${stats.pendingApprovals} pending`}
            color="bg-secondary/20"
          />
          <StatCard
            icon={DollarSign}
            label="Total Revenue"
            value={`₹${(stats.totalRevenue || 0).toFixed(0)}`}
            subtext={`${stats.totalTransactions} transactions`}
            color="bg-green-500/20"
          />
        </div>

        {/* Management Links */}
        <div className="grid md:grid-cols-4 gap-4 mb-8 animate-slide-up">
          <Link
            href="/admin/users"
            className="p-4 rounded-lg border border-border hover:border-primary bg-card/50 hover:bg-card transition-all space-y-2 group"
          >
            <Users className="w-6 h-6 text-primary group-hover:scale-110 transition-transform" />
            <p className="font-medium">Manage Users</p>
            <p className="text-xs text-muted-foreground">{stats.totalUsers} users</p>
          </Link>

          <Link
            href="/admin/products"
            className="p-4 rounded-lg border border-border hover:border-primary bg-card/50 hover:bg-card transition-all space-y-2 group"
          >
            <Package className="w-6 h-6 text-secondary group-hover:scale-110 transition-transform" />
            <p className="font-medium">Manage Products</p>
            <p className="text-xs text-muted-foreground">{stats.totalProducts} products</p>
          </Link>

          <Link
            href="/admin/wallet-requests"
            className="p-4 rounded-lg border border-border hover:border-primary bg-card/50 hover:bg-card transition-all space-y-2 group"
          >
            <TrendingUp className="w-6 h-6 text-accent group-hover:scale-110 transition-transform" />
            <p className="font-medium">Wallet Requests</p>
            <p className="text-xs text-muted-foreground">Process payments</p>
          </Link>

          <Link
            href="/admin/analytics"
            className="p-4 rounded-lg border border-border hover:border-primary bg-card/50 hover:bg-card transition-all space-y-2 group"
          >
            <BarChart3 className="w-6 h-6 text-green-500 group-hover:scale-110 transition-transform" />
            <p className="font-medium">Analytics</p>
            <p className="text-xs text-muted-foreground">View insights</p>
          </Link>
        </div>

        {/* Content Area */}
        <div className="grid md:grid-cols-3 gap-8 animate-slide-up">
          {/* Pending Approvals */}
          <div className="md:col-span-2 p-6 rounded-lg border border-border bg-card/50">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold">Recent Activity</h3>
              <Link href="/admin/activity" className="text-sm text-primary hover:underline">
                View All
              </Link>
            </div>

            {loading ? (
              <div className="space-y-3">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="h-12 bg-muted rounded-lg animate-pulse"></div>
                ))}
              </div>
            ) : recentActivities.length > 0 ? (
              <div className="space-y-3">
                {recentActivities.slice(0, 5).map((activity: any, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-3 rounded-lg border border-border/50 hover:border-border transition-colors"
                  >
                    <div className="flex-1">
                      <p className="font-medium text-sm">{activity.title}</p>
                      <p className="text-xs text-muted-foreground">{activity.description}</p>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {new Date(activity.date).toLocaleDateString()}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <p>No recent activity</p>
              </div>
            )}
          </div>

          {/* Quick Actions */}
          <div className="p-6 rounded-lg border border-border bg-card/50 space-y-4">
            <h3 className="text-xl font-bold">Quick Actions</h3>

            {stats.pendingApprovals > 0 && (
              <Link
                href="/admin/products"
                className="w-full p-4 rounded-lg border border-yellow-500/50 bg-yellow-500/10 hover:bg-yellow-500/20 transition-colors flex items-center gap-3 group"
              >
                <AlertCircle className="w-5 h-5 text-yellow-500 group-hover:scale-110 transition-transform" />
                <div className="flex-1">
                  <p className="text-sm font-medium">{stats.pendingApprovals} Pending Approvals</p>
                  <p className="text-xs text-muted-foreground">Review products</p>
                </div>
              </Link>
            )}

            <div className="space-y-2">
              <p className="text-sm font-medium text-muted-foreground">Navigation</p>
              <button className="w-full p-3 rounded-lg border border-border hover:border-primary text-left hover:bg-card transition-colors text-sm">
                System Settings
              </button>
              <button className="w-full p-3 rounded-lg border border-border hover:border-primary text-left hover:bg-card transition-colors text-sm">
                Generate Reports
              </button>
              <button className="w-full p-3 rounded-lg border border-border hover:border-primary text-left hover:bg-card transition-colors text-sm">
                Export Data
              </button>
            </div>
          </div>
        </div>
      </section>

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </main>
  )
}

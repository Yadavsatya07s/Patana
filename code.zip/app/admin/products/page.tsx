"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Navigation from "@/components/navigation"
import Toast from "@/components/toast"
import { CheckCircle, XCircle, Clock } from "lucide-react"
import { API_BASE_URL } from "@/lib/constants"

export default function AdminProductsPage() {
  const router = useRouter()
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState("pending")
  const [toast, setToast] = useState<any>(null)
  const [theme] = useState<"light" | "dark">("dark")

  useEffect(() => {
    const userType = localStorage.getItem("user_type")
    if (userType !== "admin") {
      router.push("/login")
      return
    }
    fetchProducts()
  }, [filter, router])

  const fetchProducts = async () => {
    try {
      setLoading(true)
      const token = localStorage.getItem("token")
      const response = await fetch(`${API_BASE_URL}admin.php?action=products&status=${filter}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await response.json()
      if (data.success) {
        setProducts(data.products || [])
      }
    } catch (error) {
      setToast({ message: "Failed to load products", type: "error" })
    } finally {
      setLoading(false)
    }
  }

  const handleApprove = async (productId: number) => {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch(`${API_BASE_URL}admin.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          action: "approveProduct",
          product_id: productId,
        }),
      })

      const data = await response.json()
      if (data.success) {
        setToast({ message: "Product approved!", type: "success" })
        fetchProducts()
      }
    } catch (error) {
      setToast({ message: "Failed to approve product", type: "error" })
    }
  }

  const handleReject = async (productId: number) => {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch(`${API_BASE_URL}admin.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          action: "rejectProduct",
          product_id: productId,
        }),
      })

      const data = await response.json()
      if (data.success) {
        setToast({ message: "Product rejected!", type: "success" })
        fetchProducts()
      }
    } catch (error) {
      setToast({ message: "Failed to reject product", type: "error" })
    }
  }

  return (
    <main className="min-h-screen bg-background">
      <Navigation theme={theme} toggleTheme={() => {}} isLoggedIn={true} />

      <section className="max-w-7xl mx-auto px-4 py-12">
        <div className="mb-8 animate-slide-down">
          <h1 className="text-4xl font-bold mb-4">Manage Products</h1>

          <div className="flex gap-2">
            {(["pending", "approved", "rejected"] as const).map((status) => (
              <button
                key={status}
                onClick={() => setFilter(status)}
                className={`px-4 py-2 rounded-lg font-medium transition-colors capitalize ${
                  filter === status ? "bg-primary text-primary-foreground" : "border border-border hover:border-primary"
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        <div className="p-6 rounded-lg border border-border bg-card/50 animate-slide-up">
          {loading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-20 bg-muted rounded-lg animate-pulse"></div>
              ))}
            </div>
          ) : products.length > 0 ? (
            <div className="space-y-3 overflow-x-auto">
              {products.map((product: any) => (
                <div
                  key={product.id}
                  className="flex flex-col md:flex-row md:items-center md:justify-between p-4 rounded-lg border border-border/50 hover:border-border transition-colors gap-4"
                >
                  <div className="flex-1">
                    <h3 className="font-semibold mb-1">{product.name}</h3>
                    <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
                      <span>By: {product.seller_name}</span>
                      <span>₹{product.price}</span>
                      <span>{product.category}</span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    {filter === "pending" && (
                      <>
                        <button
                          onClick={() => handleApprove(product.id)}
                          className="px-4 py-2 rounded-lg bg-green-500/10 border border-green-500/50 text-green-500 hover:bg-green-500/20 transition-colors flex items-center gap-1 text-sm font-medium"
                        >
                          <CheckCircle className="w-4 h-4" />
                          Approve
                        </button>
                        <button
                          onClick={() => handleReject(product.id)}
                          className="px-4 py-2 rounded-lg bg-red-500/10 border border-red-500/50 text-red-500 hover:bg-red-500/20 transition-colors flex items-center gap-1 text-sm font-medium"
                        >
                          <XCircle className="w-4 h-4" />
                          Reject
                        </button>
                      </>
                    )}
                    {filter === "approved" && (
                      <span className="px-3 py-1 rounded-full bg-green-500/10 text-green-500 text-xs font-medium flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" />
                        Approved
                      </span>
                    )}
                    {filter === "rejected" && (
                      <span className="px-3 py-1 rounded-full bg-red-500/10 text-red-500 text-xs font-medium flex items-center gap-1">
                        <XCircle className="w-3 h-3" />
                        Rejected
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Clock className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">No {filter} products</p>
            </div>
          )}
        </div>
      </section>

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </main>
  )
}

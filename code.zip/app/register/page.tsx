"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Eye, EyeOff, UserPlus } from "lucide-react"
import Navigation from "@/components/navigation"
import Toast from "@/components/toast"
import { API_BASE_URL } from "@/lib/constants"

export default function RegisterPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({ name: "", email: "", password: "", confirmPassword: "" })
  const [showPassword, setShowPassword] = useState(false)
  const [userType, setUserType] = useState("buyer")
  const [loading, setLoading] = useState(false)
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null)
  const [theme] = useState<"light" | "dark">("dark")

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.name || !formData.email || !formData.password || !formData.confirmPassword) {
      setToast({ message: "Please fill all fields", type: "error" })
      return
    }

    if (formData.password !== formData.confirmPassword) {
      setToast({ message: "Passwords do not match", type: "error" })
      return
    }

    if (formData.password.length < 6) {
      setToast({ message: "Password must be at least 6 characters", type: "error" })
      return
    }

    try {
      setLoading(true)
      const response = await fetch(`${API_BASE_URL}auth.php`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "register",
          name: formData.name,
          email: formData.email,
          password: formData.password,
          user_type: userType,
        }),
      })

      const data = await response.json()

      if (data.success) {
        setToast({ message: "Registration successful! Redirecting...", type: "success" })
        setTimeout(() => router.push("/login"), 1500)
      } else {
        setToast({ message: data.message || "Registration failed", type: "error" })
      }
    } catch (error) {
      setToast({ message: "Connection error", type: "error" })
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-background">
      <Navigation theme={theme} toggleTheme={() => {}} isLoggedIn={false} />

      <section className="min-h-[calc(100vh-64px)] flex items-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full mx-auto space-y-8 animate-slide-up">
          {/* Header */}
          <div className="text-center space-y-2">
            <h1 className="text-3xl font-bold">Join BWM Store</h1>
            <p className="text-muted-foreground">Create your account to get started</p>
          </div>

          {/* Form */}
          <form onSubmit={handleRegister} className="space-y-4">
            {/* User Type */}
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setUserType("buyer")}
                className={`px-4 py-2 rounded-lg border transition-all ${
                  userType === "buyer" ? "border-primary bg-primary/10" : "border-border hover:border-primary"
                }`}
              >
                Buyer
              </button>
              <button
                type="button"
                onClick={() => setUserType("seller")}
                className={`px-4 py-2 rounded-lg border transition-all ${
                  userType === "seller" ? "border-primary bg-primary/10" : "border-border hover:border-primary"
                }`}
              >
                Seller
              </button>
            </div>

            {/* Name */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Full Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Your name"
                className="w-full px-4 py-2 rounded-lg border border-border bg-card focus:border-primary focus:outline-none transition-colors"
              />
            </div>

            {/* Email */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="you@example.com"
                className="w-full px-4 py-2 rounded-lg border border-border bg-card focus:border-primary focus:outline-none transition-colors"
              />
            </div>

            {/* Password */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="Min 6 characters"
                  className="w-full px-4 py-2 rounded-lg border border-border bg-card focus:border-primary focus:outline-none transition-colors pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Confirm Password */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Confirm Password</label>
              <input
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                placeholder="Confirm your password"
                className="w-full px-4 py-2 rounded-lg border border-border bg-card focus:border-primary focus:outline-none transition-colors"
              />
            </div>

            {/* Terms */}
            <label className="flex items-start gap-2 text-sm cursor-pointer">
              <input type="checkbox" className="w-4 h-4 rounded border-border mt-0.5" required />
              <span className="text-muted-foreground">
                I agree to the{" "}
                <Link href="/terms" className="text-primary hover:underline">
                  Terms
                </Link>{" "}
                and{" "}
                <Link href="/privacy" className="text-primary hover:underline">
                  Privacy Policy
                </Link>
              </span>
            </label>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-2 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-medium hover:shadow-lg hover:shadow-primary/50 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 active:button-click"
            >
              <UserPlus className="w-4 h-4" />
              {loading ? "Creating account..." : "Create Account"}
            </button>
          </form>

          {/* Divider */}
          <div className="flex items-center gap-3">
            <div className="flex-1 h-px bg-border"></div>
            <span className="text-xs text-muted-foreground">OR</span>
            <div className="flex-1 h-px bg-border"></div>
          </div>

          {/* Login Link */}
          <div className="text-center text-sm">
            <span className="text-muted-foreground">Already have an account? </span>
            <Link href="/login" className="text-primary font-medium hover:underline">
              Login
            </Link>
          </div>
        </div>
      </section>

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </main>
  )
}

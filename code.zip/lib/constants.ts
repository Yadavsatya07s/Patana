export const API_BASE_URL = "https://satya.lovestoblog.com/bwmStore/api/"
export const APP_NAME = "BWM Store"
export const APP_TAGLINE = "Build With Satya | BWM"

# BWM Store - Setup Guide

## Project Overview
A modern digital products marketplace with user authentication, seller dashboard, admin panel, wallet system, and PWA support.

## Technology Stack
- **Frontend**: Next.js 16, React 19, TypeScript, Tailwind CSS
- **Backend**: PHP 7.4+, MySQL 5.7+
- **Authentication**: JWT-based token authentication
- **UI**: Custom dark/light theme, modern animations, responsive design

## Installation

### Backend Setup (PHP/MySQL)

1. **Upload backend files to your server:**
   \`\`\`
   https://satya.lovestoblog.com/bwmStore/
   \`\`\`

2. **Update database credentials in `config.php`:**
   \`\`\`php
   define('DB_HOST', 'your_host');
   define('DB_USER', 'your_user');
   define('DB_PASS', 'your_password');
   define('DB_NAME', 'bwm_store');
   \`\`\`

3. **Run installation:**
   - Visit: `https://satya.lovestoblog.com/bwmStore/install.php`
   - This will create all required database tables
   - Demo accounts will be created automatically

4. **Delete install.php after setup:**
   \`\`\`bash
   rm backend/install.php
   \`\`\`

### Frontend Setup (Next.js)

1. **Clone/setup the frontend project**

2. **Install dependencies:**
   \`\`\`bash
   npm install
   \`\`\`

3. **Update API base URL in `lib/constants.ts`:**
   \`\`\`typescript
   export const API_BASE_URL = 'https://satya.lovestoblog.com/bwmStore/api/'
   \`\`\`

4. **Run development server:**
   \`\`\`bash
   npm run dev
   \`\`\`

5. **Build for production:**
   \`\`\`bash
   npm run build
   npm start
   \`\`\`

## Default Demo Accounts

### Admin
- **Email:** admin@bwmstore.com
- **Password:** admin123

### Seller
- **Email:** seller@bwmstore.com
- **Password:** seller123

## API Endpoints

### Authentication
- `POST /api/auth.php` - Register/Login
  - `action: "register"` - Create new account
  - `action: "login"` - User login

### Products
- `GET /api/products.php` - List all products
- `GET /api/products.php?id=X` - Get product details
- `GET /api/products.php?featured=1` - Get featured products

### Wallet
- `GET /api/wallet.php?action=getBalance` - Get user balance
- `POST /api/wallet.php?action=addMoney` - Add money to wallet
- `POST /api/wallet.php?action=withdraw` - Request withdrawal

### Seller
- `GET /api/seller.php?action=dashboard` - Seller dashboard
- `POST /api/seller.php?action=uploadProduct` - Upload product
- `POST /api/seller.php?action=deleteProduct` - Delete product

### Admin
- `GET /api/admin.php?action=dashboard` - Admin dashboard
- `GET /api/admin.php?action=products&status=pending` - Manage products
- `POST /api/admin.php?action=approveProduct` - Approve product
- `POST /api/admin.php?action=rejectProduct` - Reject product

## File Structure

\`\`\`
Frontend:
app/
├── layout.tsx - Root layout with PWA support
├── page.tsx - Homepage
├── globals.css - Global styles with animations
├── login/ - Login page
├── register/ - Registration page
├── browse/ - Product browsing
├── product/[id]/ - Product detail page
├── wallet/ - Wallet management
├── checkout/[id]/ - Purchase checkout
├── seller/
│   ├── dashboard/ - Seller dashboard
│   └── upload/ - Product upload
└── admin/
    ├── dashboard/ - Admin dashboard
    └── products/ - Manage products

Backend:
backend/
├── config.php - Database & JWT configuration
├── install.php - Database installation script
└── api/
    ├── auth.php - Authentication endpoints
    ├── products.php - Product endpoints
    ├── wallet.php - Wallet endpoints
    ├── seller.php - Seller endpoints
    └── admin.php - Admin endpoints
\`\`\`

## Features

### User Features
- ✅ Secure registration and login
- ✅ Dark/Light theme toggle
- ✅ Product browsing with search & filters
- ✅ Category navigation
- ✅ Wishlist & product details
- ✅ Animated UI with smooth transitions
- ✅ Mobile responsive design
- ✅ PWA support (install app)

### Wallet System
- ✅ Add money via manual payment
- ✅ Add money via QR screenshot upload
- ✅ Transaction history
- ✅ Real-time balance updates
- ✅ Purchase with wallet

### Seller Features
- ✅ Dashboard with analytics
- ✅ Upload digital products
- ✅ Manage products (edit/delete)
- ✅ Track downloads & earnings
- ✅ Withdrawal requests (min ₹100)
- ✅ Product approval system

### Admin Features
- ✅ Complete dashboard with analytics
- ✅ User management
- ✅ Product approval/rejection
- ✅ Wallet request processing
- ✅ Transaction management
- ✅ System analytics

## Security Features

- ✅ JWT-based authentication
- ✅ Password hashing with bcrypt
- ✅ CORS protection
- ✅ SQL injection prevention
- ✅ Authorization checks
- ✅ Rate limiting ready
- ✅ Environment-based config

## Performance Optimizations

- ✅ Next.js image optimization
- ✅ Code splitting & lazy loading
- ✅ CSS animations with GPU acceleration
- ✅ Service worker caching
- ✅ Responsive images
- ✅ Minified assets

## Customization

### Update Branding
1. Change "BWM Store" text in components
2. Update colors in `globals.css`
3. Replace logo in `Navigation` component
4. Update app icons in `public/`

### Add Payment Gateway
1. Add Stripe/Razorpay integration
2. Create payment handler in backend
3. Update wallet system
4. Add payment UI

### Extend Database
1. Add new tables in `install.php`
2. Create corresponding API endpoints
3. Update frontend components

## Troubleshooting

### Database Connection Error
- Check credentials in `config.php`
- Verify MySQL is running
- Ensure database exists

### API Not Responding
- Check backend URL in `lib/constants.ts`
- Verify CORS headers in `config.php`
- Check PHP error logs

### Authentication Issues
- Clear localStorage: `localStorage.clear()`
- Verify JWT in browser console
- Check token expiration

## Support & Deployment

### Vercel Deployment
\`\`\`bash
vercel deploy
\`\`\`

### Traditional Hosting
1. Upload Next.js build to hosting
2. Configure Node.js environment
3. Set environment variables
4. Deploy backend PHP separately

### Domain Setup
Update `API_BASE_URL` with your production domain

---

**Build With Satya | BWM Store** ✨
